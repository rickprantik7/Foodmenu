######Installing Npm packages########
1.open command prompt
2.type npm i
3.type nodemon or node app.js


##########In the Browser###########

###For the customer
1.type http://localhost:3000
2.qr code will be generated scan it using any online qe code scanner
3.A menu will be displayed call the waiter order any choice
#######for the waiter
1.type http://localhost:3000/orders
2.Enter the items the coustomer has ordered
3.Give the bill to coustomer

########Here is the list of menu###########

type:"Chicken",
name:"Finger chicken",
price:24

type:"Chicken",
name:"Chicken wrap",
price:26

type:"Chicken",
name:"Butter chicken",
price:30

type:"Chicken",
name:"Chicken masala",
price:24

type:"Salad",
name:"Antipasto salad",
price:13

type:"Salad",
name:"BBQ pork salad",
price:11

type:"Salad",
name:"Broccoli Rabe",
price:10

type:"Salad",
name:"Chicken salad",
price:20

type:"Beef",
name:"BBQ beef",
price:24

type:"Beef",
name:"Beef wrap",
price:26

type:"Beef",
name:"Butter beef",
price:29

type:"Beef",
name:"Beef masala",
price:30

type:"Burger",
name:"Lurger burger",
price:13

type:"Burger",
name:"Double animal style",
price:11

type:"Burger",
name:"The original burger",
price:10

type:"Burger",
name:"Chicken burger",
price:20
