const foodMenu=[
  {
    type:"Chicken",
  name:"Finger chicken",
  price:24
},
{
  type:"Chicken",
name:"Chicken wrap",
price:26
},
{
  type:"Chicken",
name:"Butter chicken",
price:30
},
{
  type:"Chicken",
name:"Chicken masala",
price:24
},
{
  type:"Salad",
name:"Antipasto salad",
price:13
},
{
  type:"Salad",
name:"BBQ pork salad",
price:11
},
{
  type:"Salad",
name:"Broccoli Rabe",
price:10
},
{
  type:"Salad",
name:"Chicken salad",
price:20
},
{
  type:"Beef",
name:"BBQ beef",
price:24
},
{
  type:"Beef",
name:"Beef wrap",
price:26
},
{
  type:"Beef",
name:"Butter beef",
price:29
},
{
  type:"Beef",
name:"Beef masala",
price:30
},
{
  type:"Burger",
name:"Lurger burger",
price:13
},
{
  type:"Burger",
name:"Double animal style",
price:11
},
{
  type:"Burger",
name:"The original burger",
price:10
},
{
  type:"Burger",
name:"Chicken burger",
price:20
},
]
//console.log(foodMenu);
module.exports=  foodMenu;
