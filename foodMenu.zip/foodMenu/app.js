const express=require("express")
const mongoose=require("mongoose")
const fs = require('fs');
const qrcode = require('qrcode');
const bodyParser=require("body-parser")
const ejs= require("ejs")
const foodMenu=require('./foodMenu')
const app= express()
app.set("view engine",'ejs')
//mongoose.connect("mongodb://localhost:27017/foodMenu",{newUrlParser:true})
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static('public'))
console.log(foodMenu);
//const menuSchema= new mongoose.Schema({
  //item:{
    //name:string,
    //price:number,
  //  required:true
  //}
//})
//const menu= mongoose.model("menu",menuSchema)
app.get("/",function(req,res){
  run().catch(error => console.error(error.stack));

  async function run() {
    const ress = await qrcode.toDataURL('https://localhost:3000/menu');

    fs.writeFileSync('index.html', `<img src="${ress}">`);
    console.log('Wrote to ./qr.html');
    res.sendFile(__dirname+'/index.html')
  }
})

app.get("/menu",function(req,res){
  res.sendFile(__dirname+'/menu.html')
})
app.get("/pricing",function(req,res){

res.render('price.ejs')

})

app.get("/orders",function(req,res){

res.render('items.ejs')

})

app.post("/orders",function(req,res){
const order1=req.body.order1
const order2=req.body.order2
const order3=req.body.order3
const order4=req.body.order4

const bill=[order1,order2,order3,order4]
var price=0
for(var i=0;i<=4;i++)
{
  foodMenu.forEach(function(items) {
    if(bill[i]==items.name){
      price=price+items.price
    }

});

}
console.log(price);
res.render('price.ejs',{vala:order1,valb:order2,valc:order3,vald:order4,total:price})

})

app.listen(3000,function(){
  console.log("server is running");
})
